<?php
 
namespace App\Form\Dto;
 
use Doctrine\Common\Collections\ArrayCollection;
use App\Entity\Article;
 
class ArticlesDto
{
    /**
     * @var ArrayCollection|Article[]
     */
    protected $articles;
 
    public function __construct()
    {
        $this->articles = new ArrayCollection();
    }
 
    public function getArticles(): ArrayCollection
    {
        return $this->articles;
    }
 
    public function setArticles(ArrayCollection $articles): self
    {
        $this->articles = $articles;
 
        return $this;
    }
}