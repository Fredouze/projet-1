<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class TableauController extends AbstractController
{
    /**
     * @Route("/", name="home")
     */
    public function index()
    {
        // Tableau audio
  $sql = " 
        SELECT * FROM `article`
    ";

    $em = $this->getDoctrine()->getManager();
    $stmt = $em->getConnection()->prepare($sql);
    $stmt->execute();
    
        return $this->render('tableau.html.twig', array("user" =>  $stmt));
    }
}