<?php
 
namespace App\Controller;
 
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use App\Form\Dto\ArticlesDto;
use App\Entity\Article;
use App\Form\ArticleType;

class EnrController extends AbstractController
{
    /**
     * @Route("/enr", name="enr")
     */
    public function index(Request $request)
    {
        $articlesDto = new ArticlesDto();
        $form = $this->createForm(ArticleType::class, $articlesDto);
        $form->handleRequest($request);
 
        if ($form->isSubmitted()) {
            if ($form->isValid()) {
                $em = $this->getDoctrine()->getManager();
                foreach ($articlesDto->getArticles() as $article) {
                    $em->persist($article);
                }
                $em->flush();
            } else {
                $this->addFlash('errors', $form->getErrors(true));
            }
        }
 
        return $this->render('enr/enr.html.twig', [
            'controller_name' => 'EnrController',
            'form' => $form->createView(),
        ]);
 
    }
}