<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class TabController extends AbstractController
{
    /**
     * @Route("/", name="home")
     */
    public function index()
    {
        // Tableau audio

       $user = array(  array("psedo" => "Toto", "age" => "12" ),
               array("psedo" => "Titi", "age" => "16"),
               array("psedo" => "Rifi", "age" => "18"),
               array("psedo" => "Fifi", "age" => "20"),
               array("psedo" => "Loulou", "age" => "22"),
);
 
        $r = array_rand($user);

        return $this->render('tab.html.twig', array("user" =>  $user));
    }
}
 