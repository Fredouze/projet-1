<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class EnregistrementController extends AbstractController
{
    /**
     * @Route("/", name="enregistrement")
     */
    public function index()
    {
        // Tableau audio

       $user = array(  array("psedo" => "Toto", "age" => "12" ),
               array("psedo" => "Titi", "age" => "16"),
               array("psedo" => "Rifi", "age" => "18"),
               array("psedo" => "Fifi", "age" => "20"),
               array("psedo" => "Loulou", "age" => "22"),
);
 
        $r = array_rand($user);

        return $this->render('enregistrement.html.twig', array("user" =>  $user));
    }



    public function repousserAction($aleId) {
        $request = $this->get('request');
     
        if( $request->getMethod() == 'POST' ) {
            // Récupération de la valeur ici
     
            /* ... */

            $nbJours=$request->get('name1');


        }
     
        return indexAction();

     
}      


}
 