<?php

    namespace App\Controller;

    use Symfony\Component\HttpFoundation\Response;
    use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
    use Symfony\Component\Routing\Annotation\Route;

    class HelloController extends AbstractController
    {
        /**
        * @Route("/hello")
        */
        public function sayHello()
        {
            return new Response('Hello!');
        }
        /**
        * @Route("/bonjour/{nom}")
        */
        public function bonjour($nom)
        {
            //return new Response("Bonjour $nom !");
            return $this->render('bonjour.html.twig', [
                        'nom' => $nom,
                        ]);
        }
    }

 
 